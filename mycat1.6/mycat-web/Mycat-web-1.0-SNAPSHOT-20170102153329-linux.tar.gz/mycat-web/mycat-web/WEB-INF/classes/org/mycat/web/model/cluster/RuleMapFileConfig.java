package org.mycat.web.model.cluster;

public class RuleMapFileConfig {
	
	
	private String  configJson;

	public String getConfigJson() {
		return configJson;
	}

	public void setConfigJson(String configJson) {
		this.configJson = configJson;
	}
	
}
